"use client";

import { useEffect, useState } from "react";
import { getLatestPrice, setPrice } from "@/src/services/priceService";
import { useToast } from "@/src/components/Toast";
import { DollarSign, Check } from "lucide-react";

export default function PricePage() {
    const [currentPrice, setCurrentPrice] = useState(null);
    const [newPrice, setNewPrice] = useState("");
    const [effectiveFrom, setEffectiveFrom] = useState(
        new Date().toISOString().split("T")[0]
    );
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const { addToast } = useToast();

    useEffect(() => {
        loadPrice();
    }, []);

    const loadPrice = async () => {
        try {
            const data = await getLatestPrice();
            setCurrentPrice(data);
        } catch (error) {
            console.error("Price load error:", error);
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!newPrice || !effectiveFrom) {
            addToast("Please fill in all fields", "error");
            return;
        }
        setSaving(true);
        try {
            await setPrice({
                pricePerLiter: Number(newPrice),
                effectiveFrom: new Date(effectiveFrom),
                isActive: true,
            });
            addToast("Price updated successfully!", "success");
            setNewPrice("");
            loadPrice();
        } catch (error) {
            addToast(error.response?.data?.message || "Failed to update price", "error");
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div>
                <div className="page-header"><div><h1>Pricing</h1></div></div>
                <div className="skeleton" style={{ height: "200px", maxWidth: "500px" }} />
            </div>
        );
    }

    return (
        <div>
            <div className="page-header">
                <div>
                    <h1>Pricing</h1>
                    <p>Set and manage milk price per liter</p>
                </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: "24px", maxWidth: "800px" }}>
                {/* Current Price Card */}
                <div className="glass-card glow-primary animate-fade-in" style={{ padding: "32px", textAlign: "center" }}>
                    <div
                        style={{
                            width: "64px",
                            height: "64px",
                            borderRadius: "20px",
                            background: "linear-gradient(135deg, #10b981, #059669)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            margin: "0 auto 20px",
                            boxShadow: "0 8px 32px rgba(16, 185, 129, 0.3)",
                        }}
                    >
                        <DollarSign size={28} color="white" />
                    </div>
                    <p style={{ fontSize: "13px", color: "#94a3b8", marginBottom: "8px" }}>
                        Current Active Price
                    </p>
                    <h2 style={{ fontSize: "42px", fontWeight: "800", color: "#10b981" }}>
                        Rs {currentPrice?.pricePerLiter || "—"}
                    </h2>
                    <p style={{ fontSize: "12px", color: "#64748b", marginTop: "8px" }}>
                        per liter
                    </p>
                    {currentPrice?.effectiveFrom && (
                        <p style={{ fontSize: "12px", color: "#475569", marginTop: "12px" }}>
                            Effective since:{" "}
                            {new Date(currentPrice.effectiveFrom).toLocaleDateString()}
                        </p>
                    )}
                </div>

                {/* Set New Price */}
                <div className="glass-card animate-fade-in stagger-2" style={{ padding: "32px" }}>
                    <h3
                        style={{
                            fontSize: "18px",
                            fontWeight: "700",
                            color: "#f1f5f9",
                            marginBottom: "24px",
                        }}
                    >
                        Update Price
                    </h3>
                    <form onSubmit={handleSubmit}>
                        <div style={{ marginBottom: "20px" }}>
                            <label className="input-label">New Price (Rs per Liter)</label>
                            <input
                                type="number"
                                className="input-field"
                                placeholder="e.g. 150"
                                value={newPrice}
                                onChange={(e) => setNewPrice(e.target.value)}
                                style={{ fontSize: "18px", fontWeight: "600" }}
                            />
                        </div>
                        <div style={{ marginBottom: "24px" }}>
                            <label className="input-label">Effective From</label>
                            <input
                                type="date"
                                className="input-field"
                                value={effectiveFrom}
                                onChange={(e) => setEffectiveFrom(e.target.value)}
                            />
                        </div>
                        <button
                            type="submit"
                            className="btn-primary"
                            disabled={saving}
                            style={{
                                width: "100%",
                                padding: "14px",
                                fontSize: "15px",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                                gap: "8px",
                            }}
                        >
                            {saving ? (
                                <div
                                    className="spinner"
                                    style={{ width: "20px", height: "20px", borderWidth: "2px" }}
                                />
                            ) : (
                                <>
                                    <Check size={18} />
                                    Update Price
                                </>
                            )}
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
}
