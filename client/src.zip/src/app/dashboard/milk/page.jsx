"use client";

import { useEffect, useMemo, useState } from "react";
import {
    getAllMilk,
    updateMorningMilk,
    updateEveningMilk,
} from "@/src/services/milkService";
import { useToast } from "@/src/components/Toast";
import {
    Calendar,
    Milk,
    Search,
    RefreshCw,
} from "lucide-react";

const getToday = () => {
    const now = new Date();

    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
};

const isDeliveredStatus = (status) => {
    return (
        status === "auto_delivered" ||
        status === "delivered"
    );
};

const getDisplayStatus = (status) => {
    if (
        status === "auto_delivered" ||
        status === "delivered"
    ) {
        return "Delivered";
    }

    if (status === "not_delivered") {
        return "Not Delivered";
    }

    return "Delivered";
};

export default function MilkPage() {
    const [records, setRecords] = useState([]);
    const [selectedDate, setSelectedDate] = useState(
        getToday()
    );
    const [searchTerm, setSearchTerm] = useState("");
    const [loading, setLoading] = useState(true);
    const [savingId, setSavingId] = useState(null);
    const [editedRecords, setEditedRecords] = useState({});

    const { addToast } = useToast();

    useEffect(() => {
        loadMilkRecords(selectedDate);
    }, [selectedDate]);

    const loadMilkRecords = async (date) => {
        try {
            setLoading(true);

            const response = await getAllMilk(date);

            const milkRecords = Array.isArray(response)
                ? response
                : response?.data || [];

            setRecords(milkRecords);
            setEditedRecords({});
        } catch (error) {
            console.error(
                "Load milk records error:",
                error
            );

            setRecords([]);

            addToast(
                error.response?.data?.message ||
                "Failed to load milk records",
                "error"
            );
        } finally {
            setLoading(false);
        }
    };

    const getEditedValue = (
        recordId,
        session,
        field,
        fallback
    ) => {
        return (
            editedRecords?.[recordId]?.[session]?.[
            field
            ] ?? fallback
        );
    };

    const updateEditedRecord = (
        recordId,
        session,
        field,
        value
    ) => {
        setEditedRecords((previous) => ({
            ...previous,

            [recordId]: {
                ...previous[recordId],

                [session]: {
                    ...previous[recordId]?.[session],
                    [field]: value,
                },
            },
        }));
    };

    const handleSaveRecord = async (record) => {
        try {
            setSavingId(record._id);

            const morningExtra = Number(
                getEditedValue(
                    record._id,
                    "morning",
                    "extraQty",
                    record.morning?.extraQty || 0
                )
            );

            const morningStatus = getEditedValue(
                record._id,
                "morning",
                "status",
                record.morning?.status ||
                "auto_delivered"
            );

            const eveningExtra = Number(
                getEditedValue(
                    record._id,
                    "evening",
                    "extraQty",
                    record.evening?.extraQty || 0
                )
            );

            const eveningStatus = getEditedValue(
                record._id,
                "evening",
                "status",
                record.evening?.status ||
                "auto_delivered"
            );

            if (
                !Number.isFinite(morningExtra) ||
                morningExtra < 0
            ) {
                addToast(
                    "Morning extra quantity must be 0 or greater",
                    "error"
                );
                return;
            }

            if (
                !Number.isFinite(eveningExtra) ||
                eveningExtra < 0
            ) {
                addToast(
                    "Evening extra quantity must be 0 or greater",
                    "error"
                );
                return;
            }

            await updateMorningMilk(record._id, {
                extraQty: morningExtra,
                status: morningStatus,
            });

            await updateEveningMilk(record._id, {
                extraQty: eveningExtra,
                status: eveningStatus,
            });

            addToast(
                "Milk record updated successfully",
                "success"
            );

            setEditedRecords((previous) => {
                const updated = { ...previous };
                delete updated[record._id];
                return updated;
            });

            await loadMilkRecords(selectedDate);
        } catch (error) {
            console.error(
                "Update milk record error:",
                error
            );

            addToast(
                error.response?.data?.message ||
                "Failed to update milk record",
                "error"
            );
        } finally {
            setSavingId(null);
        }
    };

    const filteredRecords = useMemo(() => {
        const term = searchTerm
            .trim()
            .toLowerCase();

        if (!term) {
            return records;
        }

        return records.filter((record) => {
            const customerName =
                record.customer?.name ||
                record.customerId ||
                "";

            const customerPhone =
                record.customer?.phone || "";

            return (
                customerName
                    .toLowerCase()
                    .includes(term) ||
                customerPhone.includes(term)
            );
        });
    }, [records, searchTerm]);

    const dailySummary = useMemo(() => {
        return records.reduce(
            (summary, record) => {

                summary.totalQty += Number(record.totalQty || 0);
                summary.totalAmount += Number(record.totalAmount || 0);

                // Morning
                if (
                    record.morning &&
                    Number(record.morning.deliveredQty || 0) > 0
                ) {
                    summary.morningDelivered++;
                }

                // Evening
                if (
                    record.evening &&
                    Number(record.evening.deliveredQty || 0) > 0
                ) {
                    summary.eveningDelivered++;
                }

                // Not Delivered
                if (
                    record.morning?.status === "not_delivered" ||
                    record.evening?.status === "not_delivered"
                ) {
                    summary.notDelivered++;
                }

                return summary;
            },
            {
                totalQty: 0,
                totalAmount: 0,
                morningDelivered: 0,
                eveningDelivered: 0,
                notDelivered: 0,
            }
        );
    }, [records]);

    if (loading) {
        return (
            <div>
                <div className="page-header">
                    <div>
                        <h1>Milk Management</h1>
                        <p>
                            Loading daily milk records...
                        </p>
                    </div>
                </div>

                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "12px",
                    }}
                >
                    {[1, 2, 3, 4, 5].map(
                        (item) => (
                            <div
                                key={item}
                                className="skeleton"
                                style={{
                                    height: "110px",
                                    borderRadius: "16px",
                                }}
                            />
                        )
                    )}
                </div>
            </div>
        );
    }

    return (
        <div>
            <div className="page-header">
                <div>
                    <h1>Milk Management</h1>

                    <p>
                        Regular milk is counted
                        automatically. Edit only extra or
                        missed deliveries.
                    </p>
                </div>

                <button
                    type="button"
                    className="btn-secondary"
                    onClick={() =>
                        loadMilkRecords(selectedDate)
                    }
                >
                    <RefreshCw
                        size={17}
                        style={{
                            marginRight: "6px",
                            verticalAlign: "middle",
                        }}
                    />

                    Refresh
                </button>
            </div>

            <div
                style={{
                    display: "grid",
                    gridTemplateColumns:
                        "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: "16px",
                    marginBottom: "24px",
                }}
            >
                <SummaryCard
                    title="Total Milk"
                    value={`${dailySummary.totalQty.toFixed(
                        1
                    )} L`}
                    valueColor="#f1f5f9"
                />

                <SummaryCard
                    title="Total Amount"
                    value={`Rs ${dailySummary.totalAmount.toLocaleString(
                        "en-PK"
                    )}`}
                    valueColor="#10b981"
                />

                <SummaryCard
                    title="Morning Delivered"
                    value={dailySummary.morningDelivered}
                    valueColor="#60a5fa"
                />

                <SummaryCard
                    title="Evening Delivered"
                    value={dailySummary.eveningDelivered}
                    valueColor="#f59e0b"
                />

                <SummaryCard
                    title="Not Delivered"
                    value={dailySummary.notDelivered}
                    valueColor="#ef4444"
                />
            </div>

            <div
                className="glass-card"
                style={{
                    padding: "20px",
                    marginBottom: "24px",
                    display: "flex",
                    gap: "16px",
                    flexWrap: "wrap",
                    alignItems: "center",
                }}
            >
                <div
                    style={{
                        position: "relative",
                        minWidth: "220px",
                    }}
                >
                    <Calendar
                        size={18}
                        style={{
                            position: "absolute",
                            left: "14px",
                            top: "50%",
                            transform:
                                "translateY(-50%)",
                            color: "#64748b",
                        }}
                    />

                    <input
                        type="date"
                        className="input-field"
                        value={selectedDate}
                        onChange={(event) =>
                            setSelectedDate(
                                event.target.value
                            )
                        }
                        style={{
                            paddingLeft: "42px",
                        }}
                    />
                </div>

                <div
                    style={{
                        position: "relative",
                        minWidth: "260px",
                        flex: 1,
                    }}
                >
                    <Search
                        size={18}
                        style={{
                            position: "absolute",
                            left: "14px",
                            top: "50%",
                            transform:
                                "translateY(-50%)",
                            color: "#64748b",
                        }}
                    />

                    <input
                        type="text"
                        className="input-field"
                        placeholder="Search customer by name or phone..."
                        value={searchTerm}
                        onChange={(event) =>
                            setSearchTerm(
                                event.target.value
                            )
                        }
                        style={{
                            paddingLeft: "42px",
                        }}
                    />
                </div>
            </div>

            {filteredRecords.length === 0 ? (
                <div
                    className="glass-card empty-state"
                    style={{ padding: "48px" }}
                >
                    <Milk size={52} />

                    <p style={{ marginTop: "12px" }}>
                        No milk records found for this
                        date
                    </p>

                    <p
                        style={{
                            color: "#64748b",
                            fontSize: "13px",
                            marginTop: "6px",
                        }}
                    >
                        Add an active customer or refresh
                        today&apos;s records.
                    </p>
                </div>
            ) : (
                <div
                    style={{
                        display: "flex",
                        flexDirection: "column",
                        gap: "16px",
                    }}
                >
                    {filteredRecords.map((record) => (
                        <MilkRecordCard
                            key={record._id}
                            record={record}
                            saving={
                                savingId === record._id
                            }
                            getEditedValue={
                                getEditedValue
                            }
                            updateEditedRecord={
                                updateEditedRecord
                            }
                            onSave={() =>
                                handleSaveRecord(record)
                            }
                        />
                    ))}
                </div>
            )}
        </div>
    );
}

function MilkRecordCard({
    record,
    saving,
    getEditedValue,
    updateEditedRecord,
    onSave,
}) {
    return (
        <div
            className="glass-card animate-fade-in"
            style={{
                padding: "20px",
                borderRadius: "18px",
            }}
        >
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "16px",
                    flexWrap: "wrap",
                    marginBottom: "18px",
                }}
            >
                <div>
                    <h3
                        style={{
                            fontSize: "18px",
                            fontWeight: "700",
                            color: "#f1f5f9",
                        }}
                    >
                        {record.customer?.name ||
                            record.customerId}
                    </h3>

                    <p
                        style={{
                            color: "#64748b",
                            fontSize: "13px",
                        }}
                    >
                        {record.customer?.phone ||
                            "No phone"}
                    </p>
                </div>

                <div style={{ textAlign: "right" }}>
                    <p
                        style={{
                            color: "#94a3b8",
                            fontSize: "12px",
                        }}
                    >
                        Daily Total
                    </p>

                    <h3
                        style={{
                            color: "#10b981",
                            fontSize: "18px",
                        }}
                    >
                        {Number(
                            record.totalQty || 0
                        ).toFixed(1)}{" "}
                        L / Rs{" "}
                        {Number(
                            record.totalAmount || 0
                        ).toLocaleString("en-PK")}
                    </h3>
                </div>
            </div>

            <div
                style={{
                    display: "grid",
                    gridTemplateColumns:
                        "repeat(auto-fit, minmax(260px, 1fr))",
                    gap: "16px",
                }}
            >
                <SessionCard
                    title="Morning"
                    accentColor="#60a5fa"
                    background="rgba(59, 130, 246, 0.06)"
                    border="rgba(59, 130, 246, 0.25)"
                    recordId={record._id}
                    sessionName="morning"
                    session={record.morning}
                    getEditedValue={getEditedValue}
                    updateEditedRecord={
                        updateEditedRecord
                    }
                />

                <SessionCard
                    title="Evening"
                    accentColor="#f59e0b"
                    background="rgba(245, 158, 11, 0.06)"
                    border="rgba(245, 158, 11, 0.25)"
                    recordId={record._id}
                    sessionName="evening"
                    session={record.evening}
                    getEditedValue={getEditedValue}
                    updateEditedRecord={
                        updateEditedRecord
                    }
                />
            </div>

            <div
                style={{
                    display: "flex",
                    justifyContent: "flex-end",
                    marginTop: "16px",
                }}
            >
                <button
                    type="button"
                    className="btn-primary"
                    onClick={onSave}
                    disabled={saving}
                >
                    {saving
                        ? "Saving..."
                        : "Save Changes"}
                </button>
            </div>
        </div>
    );
}

function SessionCard({
    title,
    accentColor,
    background,
    border,
    recordId,
    sessionName,
    session,
    getEditedValue,
    updateEditedRecord,
}) {
    const selectedStatus = getEditedValue(
        recordId,
        sessionName,
        "status",
        session?.status || "auto_delivered"
    );

    const selectedExtraQty = getEditedValue(
        recordId,
        sessionName,
        "extraQty",
        session?.extraQty || 0
    );

    return (
        <div
            style={{
                border: `1px solid ${border}`,
                borderRadius: "14px",
                padding: "16px",
                background,
            }}
        >
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    gap: "10px",
                    marginBottom: "12px",
                }}
            >
                <h4 style={{ color: accentColor }}>
                    {title}
                </h4>

                <StatusBadge
                    status={selectedStatus}
                />
            </div>

            <p
                style={{
                    color: "#94a3b8",
                    fontSize: "13px",
                    marginBottom: "10px",
                }}
            >
                Regular quantity:{" "}
                {Number(
                    session?.baseQty || 0
                ).toFixed(1)}{" "}
                L
            </p>

            <label className="input-label">
                Extra Quantity
            </label>

            <input
                type="number"
                min="0"
                step="0.5"
                className="input-field"
                value={selectedExtraQty}
                onChange={(event) =>
                    updateEditedRecord(
                        recordId,
                        sessionName,
                        "extraQty",
                        event.target.value
                    )
                }
                disabled={
                    selectedStatus === "not_delivered"
                }
                style={{ marginBottom: "10px" }}
            />

            <label className="input-label">
                Delivery Status
            </label>

            <select
                className="select-field"
                value={selectedStatus}
                onChange={(event) =>
                    updateEditedRecord(
                        recordId,
                        sessionName,
                        "status",
                        event.target.value
                    )
                }
                style={{ marginBottom: "12px" }}
            >
                <option value="auto_delivered">
                    Delivered
                </option>

                <option value="not_delivered">
                    Not Delivered
                </option>
            </select>

            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    gap: "12px",
                    marginTop: "12px",
                }}
            >
                <div>
                    <p
                        style={{
                            color: "#64748b",
                            fontSize: "11px",
                        }}
                    >
                        Delivered
                    </p>

                    <p
                        style={{
                            color: "#f1f5f9",
                            fontWeight: "700",
                        }}
                    >
                        {Number(
                            session?.deliveredQty || 0
                        ).toFixed(1)}{" "}
                        L
                    </p>
                </div>

                <div style={{ textAlign: "right" }}>
                    <p
                        style={{
                            color: "#64748b",
                            fontSize: "11px",
                        }}
                    >
                        Amount
                    </p>

                    <p
                        style={{
                            color: "#10b981",
                            fontWeight: "700",
                        }}
                    >
                        Rs{" "}
                        {Number(
                            session?.amount || 0
                        ).toLocaleString("en-PK")}
                    </p>
                </div>
            </div>
        </div>
    );
}

function StatusBadge({ status }) {
    const delivered = isDeliveredStatus(status);

    return (
        <span
            className={
                delivered
                    ? "badge badge-success"
                    : "badge badge-danger"
            }
        >
            {getDisplayStatus(status)}
        </span>
    );
}

function SummaryCard({
    title,
    value,
    valueColor,
}) {
    return (
        <div
            className="glass-card"
            style={{ padding: "20px" }}
        >
            <p
                style={{
                    color: "#94a3b8",
                    fontSize: "13px",
                    marginBottom: "6px",
                }}
            >
                {title}
            </p>

            <h2
                style={{
                    color: valueColor,
                    fontSize: "26px",
                    fontWeight: "800",
                }}
            >
                {value}
            </h2>
        </div>
    );
}