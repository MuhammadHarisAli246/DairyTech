"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useAuth } from "@/src/hooks/useAuth";
import { getCustomers } from "@/src/services/customerService";
import { getAllMilk } from "@/src/services/milkService";
import { getLatestPrice } from "@/src/services/priceService";
import StatsCard from "@/src/components/StatsCard";
import {
  Users,
  Milk,
  Banknote,
  ClipboardCheck,
  UserPlus,
  PlusCircle,
  ArrowRight,
  CalendarDays,
} from "lucide-react";

const todayDate = () => new Date().toISOString().split("T")[0];

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState({ customers: 0, todayMilk: 0, todayAmount: 0, totalRecords: 0, currentPrice: 0 });
  const [recentRecords, setRecentRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadDashboard(); }, []);

  const loadDashboard = async () => {
    try {
      const today = todayDate();
      const [customersRes, milkRes, priceRes] = await Promise.all([
        getCustomers(), getAllMilk(today), getLatestPrice(),
      ]);
      const customers = customersRes.data || [];
      const milkRecords = milkRes.data || [];
      setStats({
        customers: customers.length,
        todayMilk: milkRecords.reduce((sum, r) => sum + (r.totalQty || 0), 0),
        todayAmount: milkRecords.reduce((sum, r) => sum + (r.totalAmount || 0), 0),
        totalRecords: milkRecords.length,
        currentPrice: priceRes?.pricePerLiter || 0,
      });
      setRecentRecords(milkRecords.slice(0, 5));
    } catch (error) {
      console.error("Dashboard load error:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="dashboard-page">
        <div className="skeleton skeleton-heading" />
        <div className="stats-grid">{[1,2,3,4].map((i) => <div key={i} className="skeleton skeleton-stat" />)}</div>
      </div>
    );
  }

  return (
    <div className="dashboard-page">
      <section className="hero-panel">
        <div>
          <span className="eyebrow"><CalendarDays size={15} /> {new Date().toLocaleDateString("en-PK", { weekday: "long", day: "numeric", month: "long" })}</span>
          <h1>Good to see you, {user?.name || "User"}</h1>
          <p>Here is a clear overview of today&apos;s dairy operations.</p>
        </div>
        <div className="hero-actions">
          <Link href="/dashboard/customers" className="btn-secondary"><UserPlus size={18} /> Add customer</Link>
          <Link href="/dashboard/milk" className="btn-primary"><PlusCircle size={18} /> Milk record</Link>
        </div>
      </section>

      <section className="stats-grid">
        <StatsCard title="Total customers" value={stats.customers} icon={<Users size={21} />} gradient="linear-gradient(135deg,#2563eb,#4f46e5)" note="Active customer base" delay={0} />
        <StatsCard title="Today's milk" value={`${stats.todayMilk.toFixed(1)} L`} icon={<Milk size={21} />} gradient="linear-gradient(135deg,#0f766e,#10b981)" note="Morning and evening" delay={1} />
        <StatsCard title="Today's sales" value={`Rs ${stats.todayAmount.toFixed(0)}`} icon={<Banknote size={21} />} gradient="linear-gradient(135deg,#d97706,#f59e0b)" note={`Rate: Rs ${stats.currentPrice || 0}/L`} delay={2} />
        <StatsCard title="Today's records" value={stats.totalRecords} icon={<ClipboardCheck size={21} />} gradient="linear-gradient(135deg,#7c3aed,#a855f7)" note="Delivery entries" delay={3} />
      </section>

      <section className="content-card">
        <div className="section-heading">
          <div>
            <span className="section-kicker">Daily activity</span>
            <h2>Today&apos;s milk records</h2>
            <p>Latest delivery entries added for your customers.</p>
          </div>
          <Link href="/dashboard/milk" className="text-link">View all <ArrowRight size={16} /></Link>
        </div>

        {recentRecords.length === 0 ? (
          <div className="empty-state"><span className="empty-icon"><Milk size={30} /></span><h3>No records yet</h3><p>Today&apos;s milk records will appear here.</p></div>
        ) : (
          <>
            <div className="desktop-table-wrap">
              <table className="data-table">
                <thead><tr><th>Customer</th><th>Date</th><th>Morning</th><th>Evening</th><th>Total</th><th>Amount</th></tr></thead>
                <tbody>{recentRecords.map((record) => (
                  <tr key={record._id}>
                    <td><strong>{record.customer?.name || record.customerId || "N/A"}</strong></td>
                    <td>{record.date ? new Date(record.date).toLocaleDateString("en-PK") : "N/A"}</td>
                    <td>{record.morning?.deliveredQty || 0} L <span className="table-status">{record.morning?.status || "pending"}</span></td>
                    <td>{record.evening?.deliveredQty || 0} L <span className="table-status">{record.evening?.status || "pending"}</span></td>
                    <td><strong>{record.totalQty || 0} L</strong></td>
                    <td className="amount-cell">Rs {record.totalAmount || 0}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <div className="mobile-record-list">
              {recentRecords.map((record) => (
                <article className="mobile-record-card" key={record._id}>
                  <div className="record-card-head"><div><strong>{record.customer?.name || record.customerId || "N/A"}</strong><span>{record.date ? new Date(record.date).toLocaleDateString("en-PK") : "N/A"}</span></div><b>Rs {record.totalAmount || 0}</b></div>
                  <div className="record-metrics"><span><small>Morning</small>{record.morning?.deliveredQty || 0} L</span><span><small>Evening</small>{record.evening?.deliveredQty || 0} L</span><span><small>Total</small>{record.totalQty || 0} L</span></div>
                </article>
              ))}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
