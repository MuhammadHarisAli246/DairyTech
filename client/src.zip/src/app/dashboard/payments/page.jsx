"use client";

import { useEffect, useMemo, useState } from "react";
import { getCustomers } from "@/src/services/customerService";
import {
    getPaymentsByCustomer,
    addPayment,
    deletePayment,
} from "@/src/services/paymentService";
import { getReceiptsByCustomer } from "@/src/services/receiptService";
import { useToast } from "@/src/components/Toast";
import Modal from "@/src/components/Modal";
import {
    Plus,
    Trash2,
    CreditCard,
    Receipt,
    Wallet,
} from "lucide-react";

const initialForm = {
    customerId: "",
    receiptId: "",
    amount: "",
    method: "cash",
    month: "",
    note: "",
};

export default function PaymentsPage() {
    const [payments, setPayments] = useState([]);
    const [customers, setCustomers] = useState([]);
    const [customerReceipts, setCustomerReceipts] = useState([]);

    const [selectedCustomer, setSelectedCustomer] = useState("");
    const [selectedMonth, setSelectedMonth] = useState("");

    const [loading, setLoading] = useState(true);
    const [loadingPayments, setLoadingPayments] = useState(false);
    const [loadingReceipts, setLoadingReceipts] = useState(false);
    const [saving, setSaving] = useState(false);

    const [modalOpen, setModalOpen] = useState(false);
    const [form, setForm] = useState(initialForm);

    const { addToast } = useToast();

    useEffect(() => {
        loadCustomers();
    }, []);

    useEffect(() => {
        if (!selectedCustomer) {
            setPayments([]);
            setCustomerReceipts([]);
            setSelectedMonth("");
            return;
        }

        loadCustomerData(selectedCustomer);
    }, [selectedCustomer]);

    const loadCustomers = async () => {
        try {
            setLoading(true);

            const response = await getCustomers();

            setCustomers(
                Array.isArray(response)
                    ? response
                    : response?.data || []
            );
        } catch (error) {
            console.error("Load customers error:", error);
            addToast("Failed to load customers", "error");
            setCustomers([]);
        } finally {
            setLoading(false);
        }
    };

    const loadCustomerData = async (customerId) => {
        await Promise.all([
            loadPayments(customerId),
            loadReceipts(customerId),
        ]);
    };

    const loadPayments = async (customerId) => {
        try {
            setLoadingPayments(true);

            const response = await getPaymentsByCustomer(customerId);

            setPayments(
                Array.isArray(response)
                    ? response
                    : response?.data || []
            );
        } catch (error) {
            console.error("Load payments error:", error);
            addToast("Failed to load payments", "error");
            setPayments([]);
        } finally {
            setLoadingPayments(false);
        }
    };

    const loadReceipts = async (customerId) => {
        try {
            setLoadingReceipts(true);

            const response = await getReceiptsByCustomer(customerId);

            setCustomerReceipts(
                Array.isArray(response)
                    ? response
                    : response?.data || []
            );
        } catch (error) {
            console.error("Load receipts error:", error);
            addToast("Failed to load customer bills", "error");
            setCustomerReceipts([]);
        } finally {
            setLoadingReceipts(false);
        }
    };

    const filteredPayments = useMemo(() => {
        if (!selectedMonth) return payments;

        return payments.filter(
            (payment) => payment.month === selectedMonth
        );
    }, [payments, selectedMonth]);

    const availableMonths = useMemo(() => {
        const months = new Set();

        customerReceipts.forEach((receipt) => {
            if (receipt.month) months.add(receipt.month);
        });

        payments.forEach((payment) => {
            if (payment.month) months.add(payment.month);
        });

        return [...months].sort().reverse();
    }, [customerReceipts, payments]);

    const paymentSummary = useMemo(() => {
        return filteredPayments.reduce(
            (summary, payment) => {
                const amount = Number(payment.amount || 0);

                summary.total += amount;

                if (payment.method === "cash") {
                    summary.cash += amount;
                } else if (payment.method === "online") {
                    summary.online += amount;
                } else if (payment.method === "check") {
                    summary.check += amount;
                }

                return summary;
            },
            {
                total: 0,
                cash: 0,
                online: 0,
                check: 0,
            }
        );
    }, [filteredPayments]);

    const selectedReceipt = useMemo(() => {
        return customerReceipts.find(
            (receipt) => receipt._id === form.receiptId
        );
    }, [customerReceipts, form.receiptId]);

    const handleCustomerChange = (customerId) => {
        setForm({
            ...initialForm,
            customerId,
        });

        if (customerId) {
            loadReceipts(customerId);
        } else {
            setCustomerReceipts([]);
        }
    };

    const handleReceiptChange = (receiptId) => {
        const receipt = customerReceipts.find(
            (item) => item._id === receiptId
        );

        setForm((previous) => ({
            ...previous,
            receiptId,
            month: receipt?.month || "",
            amount: "",
        }));
    };

    const openAddModal = async () => {
        const customerId = selectedCustomer || "";

        setForm({
            ...initialForm,
            customerId,
        });

        if (customerId) {
            await loadReceipts(customerId);
        }

        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
        setForm(initialForm);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        if (
            !form.customerId ||
            !form.receiptId ||
            !form.month ||
            !form.amount
        ) {
            addToast(
                "Customer, bill and payment amount are required",
                "error"
            );
            return;
        }

        const amount = Number(form.amount);

        if (!Number.isFinite(amount) || amount <= 0) {
            addToast(
                "Payment amount must be greater than 0",
                "error"
            );
            return;
        }

        if (
            selectedReceipt &&
            amount > Number(selectedReceipt.remainingBalance || 0)
        ) {
            addToast(
                `Payment cannot exceed remaining balance of Rs ${selectedReceipt.remainingBalance}`,
                "error"
            );
            return;
        }

        try {
            setSaving(true);

            await addPayment({
                customerId: form.customerId,
                receiptId: form.receiptId,
                month: form.month,
                amount,
                method: form.method,
                note: form.note.trim(),
            });

            addToast(
                "Payment recorded successfully",
                "success"
            );

            closeModal();

            if (selectedCustomer === form.customerId) {
                await loadCustomerData(selectedCustomer);
            }
        } catch (error) {
            console.error("Add payment error:", error);

            addToast(
                error.response?.data?.message ||
                    "Failed to record payment",
                "error"
            );
        } finally {
            setSaving(false);
        }
    };

    const handleDelete = async (payment) => {
        const confirmed = window.confirm(
            `Delete payment of Rs ${payment.amount}?`
        );

        if (!confirmed) return;

        try {
            await deletePayment(payment._id);

            addToast(
                "Payment deleted successfully",
                "success"
            );

            if (selectedCustomer) {
                await loadCustomerData(selectedCustomer);
            }
        } catch (error) {
            console.error("Delete payment error:", error);

            addToast(
                error.response?.data?.message ||
                    "Failed to delete payment",
                "error"
            );
        }
    };

    if (loading) {
        return (
            <div>
                <div className="page-header">
                    <div>
                        <h1>Payments</h1>
                        <p>Loading payment data...</p>
                    </div>
                </div>

                <div
                    className="skeleton"
                    style={{
                        height: "220px",
                        borderRadius: "16px",
                    }}
                />
            </div>
        );
    }

    return (
        <div>
            <div className="page-header">
                <div>
                    <h1>Payments</h1>
                    <p>
                        Track customer payments and automatically
                        update bill balances
                    </p>
                </div>

                <button
                    className="btn-primary"
                    onClick={openAddModal}
                >
                    <Plus
                        size={18}
                        style={{
                            marginRight: "6px",
                            verticalAlign: "middle",
                        }}
                    />
                    Add Payment
                </button>
            </div>

            <div
                className="glass-card"
                style={{
                    padding: "20px",
                    marginBottom: "24px",
                    display: "grid",
                    gridTemplateColumns:
                        "repeat(auto-fit, minmax(240px, 1fr))",
                    gap: "16px",
                }}
            >
                <div>
                    <label className="input-label">
                        Select Customer
                    </label>

                    <select
                        className="select-field"
                        value={selectedCustomer}
                        onChange={(event) =>
                            setSelectedCustomer(
                                event.target.value
                            )
                        }
                    >
                        <option value="">
                            Choose a customer...
                        </option>

                        {customers.map((customer) => (
                            <option
                                key={customer._id}
                                value={customer._id}
                            >
                                {customer.name} —{" "}
                                {customer.phone}
                            </option>
                        ))}
                    </select>
                </div>

                <div>
                    <label className="input-label">
                        Filter by Month
                    </label>

                    <select
                        className="select-field"
                        value={selectedMonth}
                        onChange={(event) =>
                            setSelectedMonth(
                                event.target.value
                            )
                        }
                        disabled={!selectedCustomer}
                    >
                        <option value="">All Months</option>

                        {availableMonths.map((month) => (
                            <option
                                key={month}
                                value={month}
                            >
                                {formatMonth(month)}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {selectedCustomer && (
                <div
                    style={{
                        display: "grid",
                        gridTemplateColumns:
                            "repeat(auto-fit, minmax(190px, 1fr))",
                        gap: "16px",
                        marginBottom: "24px",
                    }}
                >
                    <SummaryCard
                        title="Total Collection"
                        value={`Rs ${paymentSummary.total.toLocaleString(
                            "en-PK"
                        )}`}
                        color="#10b981"
                    />

                    <SummaryCard
                        title="Cash"
                        value={`Rs ${paymentSummary.cash.toLocaleString(
                            "en-PK"
                        )}`}
                        color="#3b82f6"
                    />

                    <SummaryCard
                        title="Online"
                        value={`Rs ${paymentSummary.online.toLocaleString(
                            "en-PK"
                        )}`}
                        color="#8b5cf6"
                    />

                    <SummaryCard
                        title="Check"
                        value={`Rs ${paymentSummary.check.toLocaleString(
                            "en-PK"
                        )}`}
                        color="#f59e0b"
                    />
                </div>
            )}

            <div
                className="glass-card animate-fade-in"
                style={{ overflow: "hidden" }}
            >
                {!selectedCustomer ? (
                    <div
                        className="empty-state"
                        style={{ padding: "48px" }}
                    >
                        <CreditCard size={48} />

                        <p style={{ marginTop: "12px" }}>
                            Select a customer to view payments
                        </p>
                    </div>
                ) : loadingPayments ? (
                    <div
                        style={{
                            padding: "48px",
                            textAlign: "center",
                            color: "#94a3b8",
                        }}
                    >
                        Loading payments...
                    </div>
                ) : filteredPayments.length === 0 ? (
                    <div
                        className="empty-state"
                        style={{ padding: "48px" }}
                    >
                        <Wallet size={48} />

                        <p style={{ marginTop: "12px" }}>
                            No payments found
                            {selectedMonth
                                ? " for this month"
                                : " for this customer"}
                        </p>
                    </div>
                ) : (
                    <div style={{ overflowX: "auto" }}>
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Month</th>
                                    <th>Payment Date</th>
                                    <th>Note</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                {filteredPayments.map(
                                    (payment) => (
                                        <tr key={payment._id}>
                                            <td
                                                style={{
                                                    color: "#10b981",
                                                    fontWeight: "700",
                                                    fontSize: "16px",
                                                }}
                                            >
                                                Rs{" "}
                                                {Number(
                                                    payment.amount ||
                                                        0
                                                ).toLocaleString(
                                                    "en-PK"
                                                )}
                                            </td>

                                            <td>
                                                <span
                                                    className={
                                                        payment.method ===
                                                        "cash"
                                                            ? "badge badge-success"
                                                            : payment.method ===
                                                                "online"
                                                              ? "badge badge-info"
                                                              : "badge badge-warning"
                                                    }
                                                    style={{
                                                        textTransform:
                                                            "capitalize",
                                                    }}
                                                >
                                                    {payment.method}
                                                </span>
                                            </td>

                                            <td>
                                                {formatMonth(
                                                    payment.month
                                                )}
                                            </td>

                                            <td>
                                                {payment.paymentDate
                                                    ? new Date(
                                                          payment.paymentDate
                                                      ).toLocaleString(
                                                          "en-PK"
                                                      )
                                                    : "N/A"}
                                            </td>

                                            <td
                                                style={{
                                                    color: "#94a3b8",
                                                }}
                                            >
                                                {payment.note ||
                                                    "—"}
                                            </td>

                                            <td>
                                                <button
                                                    className="btn-danger btn-sm"
                                                    onClick={() =>
                                                        handleDelete(
                                                            payment
                                                        )
                                                    }
                                                    title="Delete payment"
                                                >
                                                    <Trash2
                                                        size={14}
                                                    />
                                                </button>
                                            </td>
                                        </tr>
                                    )
                                )}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            <Modal
                isOpen={modalOpen}
                onClose={closeModal}
                title="Record Payment"
            >
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: "16px" }}>
                        <label className="input-label">
                            Customer
                        </label>

                        <select
                            className="select-field"
                            value={form.customerId}
                            onChange={(event) =>
                                handleCustomerChange(
                                    event.target.value
                                )
                            }
                            required
                        >
                            <option value="">
                                Select Customer
                            </option>

                            {customers.map((customer) => (
                                <option
                                    key={customer._id}
                                    value={customer._id}
                                >
                                    {customer.name} —{" "}
                                    {customer.phone}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div style={{ marginBottom: "16px" }}>
                        <label className="input-label">
                            Monthly Bill
                        </label>

                        <select
                            className="select-field"
                            value={form.receiptId}
                            onChange={(event) =>
                                handleReceiptChange(
                                    event.target.value
                                )
                            }
                            disabled={
                                !form.customerId ||
                                loadingReceipts
                            }
                            required
                        >
                            <option value="">
                                {loadingReceipts
                                    ? "Loading bills..."
                                    : "Select Bill"}
                            </option>

                            {customerReceipts.map(
                                (receipt) => (
                                    <option
                                        key={receipt._id}
                                        value={receipt._id}
                                        disabled={
                                            Number(
                                                receipt.remainingBalance ||
                                                    0
                                            ) <= 0
                                        }
                                    >
                                        {formatMonth(
                                            receipt.month
                                        )} — Remaining Rs{" "}
                                        {Number(
                                            receipt.remainingBalance ||
                                                0
                                        ).toLocaleString(
                                            "en-PK"
                                        )}
                                        {Number(
                                            receipt.remainingBalance ||
                                                0
                                        ) <= 0
                                            ? " (Paid)"
                                            : ""}
                                    </option>
                                )
                            )}
                        </select>
                    </div>

                    {selectedReceipt && (
                        <div
                            style={{
                                display: "grid",
                                gridTemplateColumns:
                                    "repeat(3, minmax(0, 1fr))",
                                gap: "10px",
                                padding: "14px",
                                marginBottom: "16px",
                                borderRadius: "12px",
                                background:
                                    "rgba(30, 30, 46, 0.6)",
                                border:
                                    "1px solid #3a3a52",
                            }}
                        >
                            <BillInfo
                                label="Bill"
                                value={`Rs ${Number(
                                    selectedReceipt.totalAmount ||
                                        0
                                ).toLocaleString(
                                    "en-PK"
                                )}`}
                            />

                            <BillInfo
                                label="Paid"
                                value={`Rs ${Number(
                                    selectedReceipt.paidAmount ||
                                        0
                                ).toLocaleString(
                                    "en-PK"
                                )}`}
                            />

                            <BillInfo
                                label="Remaining"
                                value={`Rs ${Number(
                                    selectedReceipt.remainingBalance ||
                                        0
                                ).toLocaleString(
                                    "en-PK"
                                )}`}
                                color="#f59e0b"
                            />
                        </div>
                    )}

                    <div
                        style={{
                            display: "grid",
                            gridTemplateColumns:
                                "1fr 1fr",
                            gap: "16px",
                            marginBottom: "16px",
                        }}
                    >
                        <div>
                            <label className="input-label">
                                Amount (Rs)
                            </label>

                            <input
                                type="number"
                                min="1"
                                max={
                                    selectedReceipt
                                        ? selectedReceipt.remainingBalance
                                        : undefined
                                }
                                className="input-field"
                                placeholder="e.g. 5000"
                                value={form.amount}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        amount: event.target.value,
                                    })
                                }
                                required
                            />
                        </div>

                        <div>
                            <label className="input-label">
                                Method
                            </label>

                            <select
                                className="select-field"
                                value={form.method}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        method: event.target.value,
                                    })
                                }
                            >
                                <option value="cash">
                                    Cash
                                </option>

                                <option value="online">
                                    Online
                                </option>

                                <option value="check">
                                    Check
                                </option>
                            </select>
                        </div>
                    </div>

                    <div style={{ marginBottom: "16px" }}>
                        <label className="input-label">
                            Month
                        </label>

                        <input
                            type="month"
                            className="input-field"
                            value={form.month}
                            readOnly
                        />
                    </div>

                    <div style={{ marginBottom: "24px" }}>
                        <label className="input-label">
                            Note (optional)
                        </label>

                        <input
                            type="text"
                            className="input-field"
                            placeholder="e.g. Paid by brother"
                            value={form.note}
                            onChange={(event) =>
                                setForm({
                                    ...form,
                                    note: event.target.value,
                                })
                            }
                        />
                    </div>

                    <div
                        style={{
                            display: "flex",
                            gap: "12px",
                            justifyContent: "flex-end",
                        }}
                    >
                        <button
                            type="button"
                            className="btn-secondary"
                            onClick={closeModal}
                            disabled={saving}
                        >
                            Cancel
                        </button>

                        <button
                            type="submit"
                            className="btn-primary"
                            disabled={
                                saving ||
                                !selectedReceipt
                            }
                        >
                            {saving
                                ? "Saving..."
                                : "Record Payment"}
                        </button>
                    </div>
                </form>
            </Modal>
        </div>
    );
}

function SummaryCard({ title, value, color }) {
    return (
        <div
            className="glass-card"
            style={{
                padding: "18px",
            }}
        >
            <p
                style={{
                    color: "#94a3b8",
                    fontSize: "13px",
                    marginBottom: "6px",
                }}
            >
                {title}
            </p>

            <h3
                style={{
                    color,
                    fontSize: "22px",
                    fontWeight: "800",
                }}
            >
                {value}
            </h3>
        </div>
    );
}

function BillInfo({ label, value, color = "#f1f5f9" }) {
    return (
        <div>
            <p
                style={{
                    color: "#64748b",
                    fontSize: "11px",
                    marginBottom: "4px",
                }}
            >
                {label}
            </p>

            <p
                style={{
                    color,
                    fontWeight: "700",
                    fontSize: "13px",
                }}
            >
                {value}
            </p>
        </div>
    );
}

function formatMonth(month) {
    if (!month) return "N/A";

    const [year, monthNumber] = month.split("-");

    if (!year || !monthNumber) return month;

    const date = new Date(
        Number(year),
        Number(monthNumber) - 1,
        1
    );

    return date.toLocaleDateString("en-PK", {
        month: "long",
        year: "numeric",
    });
}