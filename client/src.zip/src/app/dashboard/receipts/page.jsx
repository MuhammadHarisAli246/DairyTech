"use client";

import { useEffect, useState } from "react";
import BillingHeader from "@/src/components/billing/BillingHeader";
import BillingSummary from "@/src/components/billing/BillingSummary";
import BillingTable from "@/src/components/billing/BillingTable";
import ReceiptModal from "@/src/components/billing/ReceiptModal";
import PaymentModal from "@/src/components/billing/PaymentModal";
import {
    generateAllReceipts,
    getAllReceipts,
} from "@/src/services/receiptService";
import { addPayment } from "@/src/services/paymentService";
import {
    sendSingleWhatsApp,
    sendAllWhatsApp,
} from "@/src/utils/whatsapp";
import { useToast } from "@/src/components/Toast";

const getCurrentMonth = () => new Date().toISOString().slice(0, 7);

export default function ReceiptsPage() {
    const [month, setMonth] = useState(getCurrentMonth());
    const [receipts, setReceipts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [generating, setGenerating] = useState(false);
    const [savingPayment, setSavingPayment] = useState(false);
    const [selectedReceipt, setSelectedReceipt] = useState(null);
    const [receiptModalOpen, setReceiptModalOpen] = useState(false);
    const [paymentModalOpen, setPaymentModalOpen] = useState(false);

    const { addToast } = useToast();

    useEffect(() => {
        loadReceipts();
    }, [month]);

    const loadReceipts = async () => {
        try {
            setLoading(true);
            const response = await getAllReceipts(month);
            setReceipts(response.data || []);
        } catch (error) {
            addToast("Failed to load receipts", "error");
        } finally {
            setLoading(false);
        }
    };

    const handleGenerateAll = async () => {
        if (!month) {
            addToast("Please select a month", "error");
            return;
        }

        try {
            setGenerating(true);
            await generateAllReceipts({ month });
            addToast("Bills generated successfully", "success");
            loadReceipts();
        } catch (error) {
            addToast(
                error.response?.data?.message || "Failed to generate bills",
                "error"
            );
        } finally {
            setGenerating(false);
        }
    };

    const handleView = (receipt) => {
        setSelectedReceipt(receipt);
        setReceiptModalOpen(true);
    };

    const handlePayment = (receipt) => {
        setSelectedReceipt(receipt);
        setPaymentModalOpen(true);
    };

    const handlePrint = (receipt) => {
        setSelectedReceipt(receipt);
        setReceiptModalOpen(true);
        setTimeout(() => window.print(), 300);
    };

    const handleWhatsApp = (receipt) => {
        sendSingleWhatsApp(receipt);
    };

    const handleSendAll = () => {
        const validReceipts = receipts.filter((r) => r.customer?.phone);

        if (!validReceipts.length) {
            addToast("No customers with phone numbers found", "error");
            return;
        }

        sendAllWhatsApp(validReceipts);
        addToast("Opening WhatsApp messages...", "success");
    };

    const handlePaymentSubmit = async (paymentData) => {
        try {
            setSavingPayment(true);

            await addPayment(paymentData);

            addToast("Payment recorded successfully", "success");

            setPaymentModalOpen(false);
            setSelectedReceipt(null);

            await loadReceipts();
        } catch (error) {
            addToast(
                error.response?.data?.message || "Failed to record payment",
                "error"
            );
        } finally {
            setSavingPayment(false);
        }
    };

    if (loading) {
        return (
            <div>
                <div className="page-header">
                    <div>
                        <h1>Monthly Billing</h1>
                        <p>Loading bills...</p>
                    </div>
                </div>

                <div className="skeleton" style={{ height: 200 }} />
            </div>
        );
    }

    return (
        <div>
            <BillingHeader
                month={month}
                setMonth={setMonth}
                onGenerate={handleGenerateAll}
                onRefresh={loadReceipts}
                onSendAll={handleSendAll}
                generating={generating}
            />

            <BillingSummary receipts={receipts} />

            <BillingTable
                receipts={receipts}
                onView={handleView}
                onPayment={handlePayment}
                onPrint={handlePrint}
                onWhatsApp={handleWhatsApp}
            />

            <ReceiptModal
                receipt={selectedReceipt}
                isOpen={receiptModalOpen}
                onClose={() => setReceiptModalOpen(false)}
                onWhatsApp={handleWhatsApp}
                onPayment={handlePayment}
            />

            <PaymentModal
                receipt={selectedReceipt}
                isOpen={paymentModalOpen}
                onClose={() => setPaymentModalOpen(false)}
                onSubmit={handlePaymentSubmit}
                saving={savingPayment}
            />
        </div>
    );
}