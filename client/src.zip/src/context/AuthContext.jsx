"use client";

import { createContext, useContext, useEffect, useState, useCallback } from "react";

// Create context with undefined default so we can detect missing provider
const AuthContext = createContext(undefined);

/**
 * AuthProvider — wraps the app and provides auth state + actions.
 *
 * Handles:
 * - Loading user/token from localStorage on mount (SSR-safe)
 * - login() to persist credentials and update state
 * - logOut() to clear credentials and reset state
 * - `loading` flag to prevent premature redirects during hydration
 */
export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    // On mount: rehydrate auth state from localStorage
    useEffect(() => {
        try {
            if (typeof window !== "undefined") {
                const storedUser = localStorage.getItem("user");
                const storedToken = localStorage.getItem("token");

                if (storedUser && storedToken) {
                    setUser(JSON.parse(storedUser));
                } else {
                    // Partial state — clean up
                    localStorage.removeItem("user");
                    localStorage.removeItem("token");
                }
            }
        } catch (error) {
            console.error("[AuthProvider] Failed to rehydrate auth state:", error);
            // Corrupted data — clear everything
            localStorage.removeItem("user");
            localStorage.removeItem("token");
        } finally {
            setLoading(false);
        }
    }, []);

    // Login: persist token + user, then update state
    const login = useCallback((data) => {
        if (!data?.token || !data?.user) {
            console.error("[AuthProvider] login() called with invalid data:", data);
            return;
        }
        localStorage.setItem("token", data.token);
        localStorage.setItem("user", JSON.stringify(data.user));
        setUser(data.user);
    }, []);

    // Logout: clear persisted data, reset state
    const logOut = useCallback(() => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setUser(null);
    }, []);

    return (
        <AuthContext.Provider value={{ user, login, logOut, loading }}>
            {children}
        </AuthContext.Provider>
    );
};

/**
 * useAuth — safely consume the auth context.
 * Throws a clear error if used outside of <AuthProvider>.
 */
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error(
            "useAuth() was called outside of <AuthProvider>. " +
            "Make sure your component tree is wrapped in <AuthProvider>."
        );
    }
    return context;
};
