"use client";

export default function StatsCard({ title, value, icon, gradient, delay = 0, note }) {
  return (
    <article className={`stat-card animate-fade-in stagger-${delay + 1}`}>
      <div className="stat-card-top">
        <span className="stat-icon" style={{ background: gradient }}>{icon}</span>
        <span className="stat-dot" />
      </div>
      <p className="stat-title">{title}</p>
      <h3 className="stat-value">{value}</h3>
      {note && <p className="stat-note">{note}</p>}
    </article>
  );
}
