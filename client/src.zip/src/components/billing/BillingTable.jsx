"use client";

import { useMemo, useState } from "react";
import {
    Eye,
    MessageCircle,
    Printer,
    Wallet,
    Search,
    X,
} from "lucide-react";

export default function BillingTable({
    receipts,
    onView,
    onPayment,
    onPrint,
    onWhatsApp,
}) {
    const [searchTerm, setSearchTerm] = useState("");

    const filteredReceipts = useMemo(() => {
        const term = searchTerm.trim().toLowerCase();

        if (!term) {
            return receipts;
        }

        return receipts.filter((receipt) => {
            const customerName =
                receipt.customer?.name || receipt.customerId || "";

            const phone = receipt.customer?.phone || "";
            const month = receipt.month || "";
            const status = receipt.status?.replaceAll("_", " ") || "";

            return (
                customerName.toLowerCase().includes(term) ||
                phone.toLowerCase().includes(term) ||
                month.toLowerCase().includes(term) ||
                status.toLowerCase().includes(term)
            );
        });
    }, [receipts, searchTerm]);

    return (
        <div>
            <div
                className="glass-card"
                style={{
                    padding: "16px",
                    marginBottom: "16px",
                    display: "flex",
                    alignItems: "center",
                    gap: "12px",
                    flexWrap: "wrap",
                }}
            >
                <div
                    style={{
                        position: "relative",
                        flex: 1,
                        minWidth: "240px",
                    }}
                >
                    <Search
                        size={18}
                        style={{
                            position: "absolute",
                            left: "14px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#64748b",
                        }}
                    />

                    <input
                        type="text"
                        className="input-field"
                        placeholder="Search by customer, phone, month, or status..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={{
                            paddingLeft: "42px",
                            paddingRight: searchTerm ? "42px" : "14px",
                        }}
                    />

                    {searchTerm && (
                        <button
                            type="button"
                            onClick={() => setSearchTerm("")}
                            aria-label="Clear search"
                            style={{
                                position: "absolute",
                                right: "10px",
                                top: "50%",
                                transform: "translateY(-50%)",
                                width: "30px",
                                height: "30px",
                                border: "none",
                                borderRadius: "8px",
                                background: "transparent",
                                color: "#94a3b8",
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "center",
                            }}
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>

                <p
                    style={{
                        color: "#94a3b8",
                        fontSize: "13px",
                        whiteSpace: "nowrap",
                    }}
                >
                    Showing {filteredReceipts.length} of {receipts.length} bills
                </p>
            </div>

            {filteredReceipts.length === 0 ? (
                <div className="glass-card empty-state" style={{ padding: 48 }}>
                    <p>
                        {receipts.length === 0
                            ? "No bills found for this month"
                            : "No bills match your search"}
                    </p>
                </div>
            ) : (
                <div className="glass-card" style={{ overflow: "hidden" }}>
                    <div style={{ overflowX: "auto" }}>
                        <table className="data-table">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Month</th>
                                    <th>Milk</th>
                                    <th>Bill</th>
                                    <th>Paid</th>
                                    <th>Remaining</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                {filteredReceipts.map((receipt) => (
                                    <tr key={receipt._id}>
                                        <td style={{ fontWeight: 600 }}>
                                            {receipt.customer?.name ||
                                                receipt.customerId}

                                            <br />

                                            <span
                                                style={{
                                                    color: "#64748b",
                                                    fontSize: 12,
                                                }}
                                            >
                                                {receipt.customer?.phone ||
                                                    "No phone"}
                                            </span>
                                        </td>

                                        <td>{receipt.month}</td>

                                        <td>
                                            {Number(
                                                receipt.totalMilk || 0
                                            ).toFixed(1)}{" "}
                                            L
                                        </td>

                                        <td
                                            style={{
                                                color: "#10b981",
                                                fontWeight: 700,
                                            }}
                                        >
                                            Rs {receipt.totalAmount || 0}
                                        </td>

                                        <td>
                                            Rs {receipt.paidAmount || 0}
                                        </td>

                                        <td
                                            style={{
                                                color: "#f59e0b",
                                                fontWeight: 700,
                                            }}
                                        >
                                            Rs{" "}
                                            {receipt.remainingBalance || 0}
                                        </td>

                                        <td>
                                            <span
                                                className={
                                                    receipt.status === "paid"
                                                        ? "badge badge-success"
                                                        : receipt.status ===
                                                            "partially_paid"
                                                          ? "badge badge-warning"
                                                          : "badge badge-danger"
                                                }
                                                style={{
                                                    textTransform: "capitalize",
                                                }}
                                            >
                                                {receipt.status?.replaceAll(
                                                    "_",
                                                    " "
                                                )}
                                            </span>
                                        </td>

                                        <td>
                                            <div
                                                style={{
                                                    display: "flex",
                                                    gap: 8,
                                                }}
                                            >
                                                <button
                                                    className="btn-secondary btn-sm"
                                                    onClick={() =>
                                                        onView(receipt)
                                                    }
                                                    title="View bill"
                                                >
                                                    <Eye size={14} />
                                                </button>

                                                <button
                                                    className="btn-secondary btn-sm"
                                                    onClick={() =>
                                                        onPayment(receipt)
                                                    }
                                                    title="Record payment"
                                                    disabled={
                                                        receipt.remainingBalance <=
                                                        0
                                                    }
                                                >
                                                    <Wallet size={14} />
                                                </button>

                                                <button
                                                    className="btn-secondary btn-sm"
                                                    onClick={() =>
                                                        onPrint(receipt)
                                                    }
                                                    title="Print bill"
                                                >
                                                    <Printer size={14} />
                                                </button>

                                                <button
                                                    className="btn-primary btn-sm"
                                                    onClick={() =>
                                                        onWhatsApp(receipt)
                                                    }
                                                    title="Send on WhatsApp"
                                                    disabled={
                                                        !receipt.customer?.phone
                                                    }
                                                >
                                                    <MessageCircle size={14} />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
}