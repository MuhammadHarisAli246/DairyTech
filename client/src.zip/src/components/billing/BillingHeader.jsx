"use client";

import { Calendar, RefreshCw, FileText, MessageCircle } from "lucide-react";

export default function BillingHeader({
    month,
    setMonth,
    onGenerate,
    onRefresh,
    onSendAll,
    generating,
}) {
    return (
        <div className="glass-card" style={{ padding: 24, marginBottom: 24 }}>
            <div
                style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 20,
                }}
            >
                <div>
                    <h1 style={{ fontSize: 28, fontWeight: 700 }}>
                        Monthly Billing
                    </h1>

                    <p style={{ color: "#94a3b8" }}>
                        Generate, manage and share customer bills.
                    </p>
                </div>

                <div
                    style={{
                        display: "flex",
                        gap: 12,
                        flexWrap: "wrap",
                        alignItems: "center",
                    }}
                >
                    <div style={{ position: "relative" }}>
                        <Calendar
                            size={18}
                            style={{
                                position: "absolute",
                                left: 12,
                                top: 12,
                                color: "#94a3b8",
                            }}
                        />

                        <input
                            type="month"
                            className="input-field"
                            style={{ paddingLeft: 40 }}
                            value={month}
                            onChange={(e) => setMonth(e.target.value)}
                        />
                    </div>

                    <button
                        className="btn-primary"
                        onClick={onGenerate}
                        disabled={generating}
                    >
                        <FileText size={18} />
                        &nbsp;
                        {generating
                            ? "Generating..."
                            : "Generate Bills"}
                    </button>

                    <button
                        className="btn-secondary"
                        onClick={onRefresh}
                    >
                        <RefreshCw size={18} />
                        &nbsp;
                        Refresh
                    </button>

                    <button
                        className="btn-success"
                        onClick={onSendAll}
                    >
                        <MessageCircle size={18} />
                        &nbsp;
                        Send All
                    </button>
                </div>
            </div>
        </div>
    );
}