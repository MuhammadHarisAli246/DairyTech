"use client";

import {
    Users,
    Receipt,
    Milk,
    DollarSign,
    Wallet,
    AlertTriangle,
    CheckCircle2,
    Clock3,
    XCircle,
} from "lucide-react";

export default function BillingSummary({ receipts }) {
    const summary = receipts.reduce(
        (acc, receipt) => {
            acc.customers++;

            acc.bills++;

            acc.totalMilk += Number(receipt.totalMilk || 0);

            acc.totalAmount += Number(receipt.totalAmount || 0);

            acc.paidAmount += Number(receipt.paidAmount || 0);

            acc.remainingBalance += Number(
                receipt.remainingBalance || 0
            );

            switch (receipt.status) {
                case "paid":
                    acc.paidBills++;
                    break;

                case "partially_paid":
                    acc.partialBills++;
                    break;

                default:
                    acc.unpaidBills++;
            }

            return acc;
        },
        {
            customers: 0,
            bills: 0,
            paidBills: 0,
            partialBills: 0,
            unpaidBills: 0,
            totalMilk: 0,
            totalAmount: 0,
            paidAmount: 0,
            remainingBalance: 0,
        }
    );

    const cards = [
        {
            title: "Customers",
            value: summary.customers,
            icon: Users,
            color: "#3b82f6",
        },

        {
            title: "Bills",
            value: summary.bills,
            icon: Receipt,
            color: "#8b5cf6",
        },

        {
            title: "Paid Bills",
            value: summary.paidBills,
            icon: CheckCircle2,
            color: "#10b981",
        },

        {
            title: "Partial Bills",
            value: summary.partialBills,
            icon: Clock3,
            color: "#f59e0b",
        },

        {
            title: "Unpaid Bills",
            value: summary.unpaidBills,
            icon: XCircle,
            color: "#ef4444",
        },

        {
            title: "Total Milk",
            value: `${summary.totalMilk.toFixed(1)} L`,
            icon: Milk,
            color: "#06b6d4",
        },

        {
            title: "Total Billing",
            value: `Rs ${summary.totalAmount.toLocaleString()}`,
            icon: DollarSign,
            color: "#22c55e",
        },

        {
            title: "Collection",
            value: `Rs ${summary.paidAmount.toLocaleString()}`,
            icon: Wallet,
            color: "#14b8a6",
        },

        {
            title: "Outstanding",
            value: `Rs ${summary.remainingBalance.toLocaleString()}`,
            icon: AlertTriangle,
            color: "#f97316",
        },
    ];

    return (
        <div
            style={{
                display: "grid",
                gridTemplateColumns:
                    "repeat(auto-fit,minmax(220px,1fr))",
                gap: 18,
                marginBottom: 24,
            }}
        >
            {cards.map((card) => {
                const Icon = card.icon;

                return (
                    <div
                        key={card.title}
                        className="glass-card"
                        style={{
                            padding: 20,
                            transition: "0.3s",
                        }}
                    >
                        <div
                            style={{
                                display: "flex",
                                justifyContent: "space-between",
                                alignItems: "center",
                            }}
                        >
                            <div>
                                <p
                                    style={{
                                        color: "#94a3b8",
                                        fontSize: 13,
                                    }}
                                >
                                    {card.title}
                                </p>

                                <h2
                                    style={{
                                        color: "#f8fafc",
                                        fontWeight: 800,
                                        fontSize: 24,
                                        marginTop: 6,
                                    }}
                                >
                                    {card.value}
                                </h2>
                            </div>

                            <div
                                style={{
                                    width: 48,
                                    height: 48,
                                    borderRadius: 12,
                                    background: `${card.color}20`,
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                }}
                            >
                                <Icon
                                    size={24}
                                    color={card.color}
                                />
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
    );
}