"use client";

import { Search } from "lucide-react";

export default function DataTable({
    columns,
    data,
    loading,
    emptyMessage = "No records found",
    onSearch,
    searchPlaceholder = "Search..."
}) {
    if (loading) {
        return (
            <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="skeleton" style={{ height: "60px" }} />
                ))}
            </div>
        );
    }

    return (
        <div className="animate-fade-in">
            {onSearch && (
                <div style={{ marginBottom: "20px", position: "relative", maxWidth: "400px" }}>
                    <Search
                        size={18}
                        style={{
                            position: "absolute",
                            left: "14px",
                            top: "50%",
                            transform: "translateY(-50%)",
                            color: "#64748b",
                        }}
                    />
                    <input
                        type="text"
                        className="input-field"
                        placeholder={searchPlaceholder}
                        onChange={(e) => onSearch(e.target.value)}
                        style={{ paddingLeft: "42px" }}
                    />
                </div>
            )}

            <div className="glass-card" style={{ overflow: "hidden" }}>
                {data.length === 0 ? (
                    <div className="empty-state">
                        <p>{emptyMessage}</p>
                    </div>
                ) : (
                    <div style={{ overflowX: "auto" }}>
                        <table className="data-table">
                            <thead>
                                <tr>
                                    {columns.map((col, idx) => (
                                        <th key={idx} style={col.style}>{col.header}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {data.map((row, rowIdx) => (
                                    <tr key={row._id || rowIdx}>
                                        {columns.map((col, colIdx) => (
                                            <td key={colIdx} style={col.style}>
                                                {col.render ? col.render(row) : row[col.key]}
                                            </td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}
